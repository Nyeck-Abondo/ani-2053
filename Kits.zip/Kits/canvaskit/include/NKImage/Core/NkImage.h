#pragma once
// AUTEUR : TEUGUIA TADJUIDJE Rodolf Séderis — Rihen
/**
 * @File    NkImage.h
 * @Brief   NkImage — chargement/sauvegarde/manipulation d'images, sans dépendance externe.
 *          Algorithmes inflate/deflate adaptés de stb_image v2.16 (public domain, Sean Barrett).
 *
 * ─── PHILOSOPHIE DE L'API ────────────────────────────────────────────────────
 *
 *  `NkImage` est un TYPE VALEUR. Une image se déclare, se remplit, et libère ses
 *  pixels toute seule à la fin de sa portée, comme n'importe quelle variable
 *  locale. Il n'existe plus d'API « tas » : AUCUNE méthode ne rend un
 *  `NkImage *`, et `Free()` N'EXISTE PLUS.
 *
 *  ⚠️ Ne réintroduisez pas de `NkImage *` possédé. C'est la forme qui a produit
 *  120 sites divergents et deux `c0000374` en production : `Free()` faisait
 *  `nkFree(this)`, et rien ne distinguait une instance du tas d'une instance
 *  valeur. Historique complet : DETTE_LISIBILITE.md, chantier 12.
 *
 *  1. FABRIQUES  → retournent `NkImage` PAR VALEUR
 *     (le move-ctor transfère le buffer : aucune copie de pixels)
 *     - NkImage::Alloc(...)       image vide, fabrique bas niveau des codecs
 *     - NkImage::Wrap(...)        vue NON-OWNING sur un buffer externe
 *     - NkImage::Create(...)      image remplie d'une couleur
 *     - NkImage::ConvertToTexture(...)  tone-mapping HDR→LDR
 *     - img.Convert(fmt) · img.Resize(...) · img.Crop(...) · img.Copy() ·
 *       img.CopyAs(fmt)           transforment SANS toucher à la source et
 *                                 rendent la nouvelle image par valeur
 *     ÉCHEC : l'image rendue est INVALIDE — on teste `IsValid()`, il n'y a plus
 *     de `nullptr`. La source n'est jamais modifiée, même en cas d'échec.
 *
 *  2. API INSTANCE  → retourne `bool`  (opère sur *this, aucune allocation visible)
 *     - img.Create(...)           crée/réinitialise *this
 *     - img.Load(path)            charge un fichier dans *this
 *     - img.LoadFromMemory(...)   charge depuis un buffer mémoire dans *this
 *     - img.Copy(src, x, y, area, clip)  copie une région de src dans *this
 *     - img.CopyTo(dst)           copie *this dans une image existante
 *     Ces méthodes libèrent automatiquement l'ancien buffer avant de remplir *this.
 *
 *  RÈGLE DE MÉMOIRE :
 *    Les PIXELS sont libérés par le destructeur, ou par `Unload()` qui vide
 *    l'image en la laissant réutilisable. Rien d'autre n'est à libérer à la main.
 *    Les buffers ENCODÉS (EncodePNG, EncodeJPEG, …) restent des `uint8 *` bruts
 *    et DOIVENT être libérés avec nkentseu::memory::NkFree(ptr).  Ne jamais
 *    utiliser std::free / delete[] : l'allocateur custom NKMemory n'est pas
 *    compatible avec le heap CRT standard (crash c0000374 sur Windows).
 *
 * @Author  TEUGUIA TADJUIDJE Rodolf Séderis
 * @License Proprietary - All Rights Reserved (see LICENSE)
 */

#include "NkImageExport.h"
#include "NKMath/NKMath.h"		  // math::NkColor, math::NkIntRect
#include "NKStream/NKIResource.h" // interface ressource CPU commune
#include <cstdio>

namespace nkentseu {

	// ─────────────────────────────────────────────────────────────────────────────
	//  Formats pixel supportés
	// ─────────────────────────────────────────────────────────────────────────────

	/**
	 * @enum NkImagePixelFormat
	 * Décrit le layout et la profondeur de chaque pixel stocké en mémoire CPU.
	 *
	 * LDR (Low Dynamic Range, entiers 8 bits par canal) :
	 *   NK_GRAY8     — 1 octet/pixel  : luminance
	 *   NK_GRAY_A16  — 2 octets/pixel : luminance + alpha
	 *   NK_RGB24     — 3 octets/pixel : rouge, vert, bleu
	 *   NK_RGBA32    — 4 octets/pixel : rouge, vert, bleu, alpha
	 *
	 * HDR (High Dynamic Range, flottants 32 bits par canal) :
	 *   NK_RGB96F    — 12 octets/pixel : RGB flottant
	 *   NK_RGBA128F  — 16 octets/pixel : RGBA flottant
	 */
	enum class NkImagePixelFormat : uint8 {
		NK_UNKNOWN = 0,
		NK_GRAY8 = 1,
		NK_GRAY_A16 = 2,
		NK_RGB24 = 3,
		NK_RGBA32 = 4,
		NK_RGBA128F = 5,
		NK_RGB96F = 6,
	};

	/** Retourne le nombre de canaux logiques pour un format donné. */
	NKIMG_INLINE constexpr int32 ChannelsOf(NkImagePixelFormat f) noexcept {
		switch (f) {
			case NkImagePixelFormat::NK_GRAY8:
				return 1;
			case NkImagePixelFormat::NK_GRAY_A16:
				return 2;
			case NkImagePixelFormat::NK_RGB24:
				return 3;
			case NkImagePixelFormat::NK_RGBA32:
				return 4;
			case NkImagePixelFormat::NK_RGBA128F:
				return 4;
			case NkImagePixelFormat::NK_RGB96F:
				return 3;
			default:
				return 0;
		}
	}

	/** Retourne le nombre d'octets occupés par un pixel complet. */
	NKIMG_INLINE constexpr int32 BytesPerPixelOf(NkImagePixelFormat f) noexcept {
		switch (f) {
			case NkImagePixelFormat::NK_GRAY8:
				return 1;
			case NkImagePixelFormat::NK_GRAY_A16:
				return 2;
			case NkImagePixelFormat::NK_RGB24:
				return 3;
			case NkImagePixelFormat::NK_RGBA32:
				return 4;
			case NkImagePixelFormat::NK_RGBA128F:
				return 16;
			case NkImagePixelFormat::NK_RGB96F:
				return 12;
			default:
				return 0;
		}
	}

	// ─────────────────────────────────────────────────────────────────────────────
	//  Formats de fichier supportés
	// ─────────────────────────────────────────────────────────────────────────────

	/**
	 * @enum NkImageFormat
	 * Identifie le format de conteneur/compression d'un fichier image.
	 * Détecté automatiquement depuis la signature binaire (magic bytes)
	 * dans NkImage::DetectFormat().
	 */
	enum class NkImageFormat : uint8 {
		NK_UNKNOWN = 0,
		NK_PNG,	 ///< Portable Network Graphics (.png)
		NK_JPEG, ///< JPEG (.jpg, .jpeg)
		NK_BMP,	 ///< Windows Bitmap (.bmp)
		NK_TGA,	 ///< Truevision TGA (.tga)
		NK_HDR,	 ///< Radiance HDR (.hdr) — RGB96F
		NK_PPM,	 ///< Portable Pixmap (.ppm)
		NK_PGM,	 ///< Portable Graymap (.pgm)
		NK_PBM,	 ///< Portable Bitmap (.pbm)
		NK_QOI,	 ///< Quite OK Image (.qoi)
		NK_GIF,	 ///< Graphics Interchange Format (.gif)
		NK_ICO,	 ///< Windows Icon (.ico)
		NK_SVG,	 ///< Scalable Vector Graphics (.svg) — rastérisé via NkSVGCodec
		NK_EXR,	 ///< OpenEXR (.exr) — RGB96F / RGBA128F via NkEXRCodec
	};

	// ─────────────────────────────────────────────────────────────────────────────
	//  Filtres de redimensionnement
	// ─────────────────────────────────────────────────────────────────────────────

	/**
	 * @enum NkResizeFilter
	 * Algorithme d'interpolation utilisé par NkImage::Resize().
	 *
	 *   NK_NEAREST   — plus proche voisin (rapide, effet pixelisé)
	 *   NK_BILINEAR  — bilinéaire (bon compromis qualité/vitesse, défaut)
	 *   NK_BICUBIC   — bicubique (meilleure qualité, plus lent)
	 *   NK_LANCZOS3  — Lanczos-3 (qualité maximale, lent)
	 */
	enum class NkResizeFilter : uint8 {
		NK_NEAREST,
		NK_BILINEAR,
		NK_BICUBIC,
		NK_LANCZOS3,
	};

	// ─────────────────────────────────────────────────────────────────────────────
	//  NkImage
	// ─────────────────────────────────────────────────────────────────────────────

	/**
	 * @class NkImage
	 *
	 * Conteneur d'image CPU avec gestion autonome de la mémoire.
	 *
	 * OWNERSHIP :
	 *   Par défaut (mOwning=true), NkImage possède son buffer pixel et le libère
	 *   dans le destructeur.  Les images créées via Wrap() sont non-owning
	 *   (mOwning=false) : elles n'appellent jamais free sur les pixels.
	 *
	 * COPIE :
	 *   La copie par valeur est désactivée (= delete) pour éviter les doubles-free
	 *   accidentels.  Utiliser Copy() (deep clone) ou le move constructor.
	 *
	 * STRIDE :
	 *   Le stride (bytes par ligne) est aligné sur 4 octets : stride = (w*bpp+3)&~3.
	 *   Utiliser RowPtr(y) pour accéder à la ligne y de façon portable.
	 */
	class NKENTSEU_IMAGE_API NkImage : public NKIResource {
		public:
			// ── Cycle de vie ──────────────────────────────────────────────────────────

			/** Constructeur par défaut : image invalide (pixels=null, w=h=0). */
			NkImage() noexcept = default;

			/**
			 * Destructeur : libère mPixels si mOwning==true.
			 * Virtuel (hérité de NKIResource). C'est le SEUL chemin de libération des
			 * pixels avec Unload() : il n'y a plus de Free() ni d'instance du tas.
			 */
			~NkImage() noexcept override;

			/** Copie désactivée — utiliser Copy() pour un clone explicite. */
			NkImage(const NkImage &) = delete;
			NkImage &operator=(const NkImage &) = delete;

			/**
			 * Move constructor : transfère le buffer sans copie ni allocation.
			 * Après le move, `other` est dans un état valide mais vide (IsValid()==false).
			 */
			NkImage(NkImage &&other) noexcept;

			/**
			 * Move assignment : libère l'éventuel buffer existant puis transfère.
			 * Self-assignment sécurisé (this==&other est testé).
			 */
			NkImage &operator=(NkImage &&other) noexcept;

			// ── API INSTANCE : Create / Load — opèrent sur *this, retournent bool ────
			//    Ces méthodes libèrent automatiquement le buffer précédent avant
			//    d'initialiser *this.  Elles sont pensées pour une utilisation en valeur
			//    (NkImage img; img.Load("foo.png")).

			/**
			 * Crée une image de dimensions (width × height) en mémoire, remplie avec
			 * la couleur `color` (composantes RGBA dans math::NkColor).
			 *
			 * @param width            Largeur en pixels (> 0).
			 * @param height           Hauteur en pixels (> 0).
			 * @param color            Couleur de remplissage (RGBA).
			 * @param desiredChannels  Nombre de canaux souhaité (1–4, défaut 4 → RGBA32).
			 * @return true si l'allocation a réussi et *this est valide.
			 */
			bool Create(uint32 width, uint32 height, math::NkColor color, int32 desiredChannels = 4) noexcept;

			// ── NKIResource : surcharges « minces » (signatures EXACTES de
			//    l'interface). Elles délèguent aux versions riches ci-dessous.
			//    Important : les versions riches n'ont PLUS de paramètre par
			//    défaut, afin que LoadFromMemory(data, size) (2 args) résolve
			//    sans ambiguïté vers l'override d'interface et non vers la
			//    version à 3 arguments (sinon name-hiding + classe abstraite).

			/** [NKIResource] Charge un fichier image (canaux natifs). Délègue à Load(path, 0). */
			bool LoadFromFile(const char *path) override {
				return Load(path, 0);
			}

			/** [NKIResource] Charge depuis un buffer mémoire (canaux natifs). */
			bool LoadFromMemory(const void *data, usize size) override {
				return LoadFromMemory(data, size, 0);
			}

			/** [NKIResource] Charge depuis un flux NkStream (lit tout le flux puis décode). */
			bool LoadFromStream(NkStream &stream) override;

			/**
			 * Charge une image depuis un fichier sur disque.
			 * Sur Android, tente automatiquement l'AAssetManager si fopen échoue.
			 *
			 * @param path             Chemin UTF-8 vers le fichier image.
			 * @param desiredChannels  0 = canaux natifs du fichier, 1–4 = conversion forcée.
			 * @return true si le chargement et le décodage ont réussi.
			 */
			bool Load(const char *path, int32 desiredChannels = 0) noexcept;

			/**
			 * Surcharge confort uint8* à 2 arguments (canaux natifs).
			 * Évite un static_cast côté appelant tout en conservant un chemin direct.
			 */
			bool LoadFromMemory(const uint8 *data, usize size) noexcept {
				return LoadFromMemory(data, size, 0);
			}

			/**
			 * Charge une image depuis un buffer mémoire brut (void*), canaux explicites.
			 * Surcharge pratique pour les APIs C qui manipulent void* (ex: fread).
			 * Délègue vers la surcharge const uint8* après un static_cast sécurisé.
			 *
			 * @param data             Pointeur vers les données encodées (PNG, JPEG, …).
			 * @param size             Taille du buffer en octets.
			 * @param desiredChannels  0 = canaux natifs, 1–4 = conversion forcée.
			 * @return true si le chargement et le décodage ont réussi.
			 */
			bool LoadFromMemory(const void *data, usize size, int32 desiredChannels) noexcept;

			/**
			 * Charge une image depuis un buffer mémoire typé uint8*, canaux explicites.
			 * C'est l'implémentation réelle ; la surcharge void* délègue ici.
			 *
			 * @param data             Pointeur vers les données encodées.
			 * @param size             Taille du buffer en octets (>= 4).
			 * @param desiredChannels  0 = canaux natifs, 1–4 = conversion forcée.
			 * @return true si le chargement et le décodage ont réussi.
			 */
			bool LoadFromMemory(const uint8 *data, usize size, int32 desiredChannels) noexcept;

			// ── FABRIQUES : retournent une NkImage PAR VALEUR ─────────────────────────
			//    Le resultat se detruit tout seul. En cas d'echec il est INVALIDE
			//    (IsValid()==false) : il n'y a pas de nullptr a tester.

			/**
			 * Crée une image allouée sur le heap, remplie avec une couleur RGBA packed.
			 *
			 * @param width            Largeur en pixels.
			 * @param height           Hauteur en pixels.
			 * @param desiredChannels  0 ou 4 → RGBA32, 1 → GRAY8, 2 → GRAY_A16, 3 → RGB24.
			 * @param color            Couleur RGBA packed big-endian : 0xRRGGBBAA.
			 *                         0x00000000 = transparent black (buffer zero-fill).
			 * @return La nouvelle image, ou une image INVALIDE en cas d'échec.
			 */
			static NkImage Create(uint32 width, uint32 height, int32 desiredChannels = 0, uint32 color = 0) noexcept;

			/**
			 * Surcharge de Create() avec format pixel explicite.
			 * Plus précise que la version par canaux quand on connaît le format exact.
			 *
			 * @param fmt   Format pixel cible.
			 * @param color Couleur RGBA packed big-endian (0xRRGGBBAA).
			 */
			static NkImage Create(uint32 width, uint32 height, NkImagePixelFormat fmt, uint32 color = 0) noexcept;

			// ── NKIResource : surcharges Save « minces » (signatures exactes) ───────────
			//    Délèguent aux variantes riches. SaveToMemory encode en PNG par défaut
			//    (lossless universel) ; `out` est alloué via NkAlloc → NkFree (voir
			//    EncodePNG). Le format de SaveToFile/Stream est PNG si l'extension
			//    n'est pas explicite (SaveToStream) ou déduit de l'extension (SaveToFile).

			/** [NKIResource] Sauvegarde via l'extension du chemin (qualité JPEG 90 par défaut). */
			bool SaveToFile(const char *path) const override {
				return Save(path, 90);
			}

			/** [NKIResource] Encode en PNG dans un buffer mémoire (out à libérer avec NkFree). */
			bool SaveToMemory(uint8 *&out, usize &size) const override {
				return EncodePNG(out, size);
			}

			/** [NKIResource] Encode en PNG et écrit le résultat dans le flux. */
			bool SaveToStream(NkStream &stream) const override;

			// ── Sauvegarde sur disque ──────────────────────────────────────────────────

			/**
			 * Sauvegarde l'image dans le format déduit de l'extension du chemin.
			 * Extensions reconnues : png, jpg/jpeg, bmp, tga, ppm/pgm, hdr, qoi.
			 *
			 * @param path    Chemin de sortie (l'extension détermine le format).
			 * @param quality Qualité JPEG [1–100], ignoré pour les autres formats.
			 * @return true si l'écriture a réussi.
			 */
			bool Save(const char *path, int32 quality = 90) const noexcept;
			bool SavePNG(const char *path) const noexcept;
			bool SaveJPEG(const char *path, int32 quality = 90) const noexcept;
			bool SaveBMP(const char *path) const noexcept;
			bool SaveTGA(const char *path) const noexcept;
			bool SavePPM(const char *path) const noexcept;
			bool SaveHDR(const char *path) const noexcept;
			bool SaveEXR(const char *path) const noexcept; ///< EXR scanline FLOAT (compression NONE).
			bool SaveQOI(const char *path) const noexcept;
			bool SaveGIF(const char *path) const noexcept; ///< Palette 256 (median-cut) + LZW.
			bool SaveWebP(const char *path, bool lossless = true,
						  int32 quality = 90) const noexcept; ///< Non implémenté.
			bool SaveSVG(const char *path) const noexcept;	  ///< Non implémenté.

			// ── Encodage en mémoire ────────────────────────────────────────────────────
			//
			//    `out` est alloué via NkAlloc (allocateur NKMemory).
			//    L'appelant DOIT libérer avec : nkentseu::memory::NkFree(out)
			//    NE PAS utiliser std::free / delete[] — incompatible avec NkAlloc
			//    et provoque une corruption du heap sur Windows (exception c0000374).

			bool EncodePNG(uint8 *&out, usize &size) const noexcept;
			bool EncodeJPEG(uint8 *&out, usize &size, int32 quality = 90) const noexcept;
			bool EncodeBMP(uint8 *&out, usize &size) const noexcept;
			bool EncodeTGA(uint8 *&out, usize &size) const noexcept;
			bool EncodeQOI(uint8 *&out, usize &size) const noexcept;

			// ── Manipulation in-place ──────────────────────────────────────────────────

			/** Retourne l'image verticalement (flip autour de l'axe horizontal). */
			void FlipVertical() noexcept;

			/** Retourne l'image horizontalement (flip autour de l'axe vertical). */
			void FlipHorizontal() noexcept;

			/**
			 * Pré-multiplie les canaux RGB par l'alpha.
			 * Opération destructrice : ne s'applique qu'aux images NK_RGBA32.
			 * Utile avant l'upload GPU pour le blending correct.
			 */
			void PremultiplyAlpha() noexcept;

			/**
			 * Convertit l'image vers un nouveau format pixel.
			 * Rend la nouvelle image PAR VALEUR ; *this n'est pas modifiée.
			 * Si newFmt == mFormat, fait un clone pur.
			 * Conversions HDR↔LDR supportées via troncature/normalisation.
			 */
			NkImage Convert(NkImagePixelFormat newFmt) const noexcept;

			/**
			 * Redimensionne l'image à (nw × nh) pixels.
			 * Rend la nouvelle image PAR VALEUR ; *this n'est pas modifiée.
			 *
			 * @param f  Filtre d'interpolation (défaut : NK_BILINEAR).
			 */
			NkImage Resize(int32 nw, int32 nh, NkResizeFilter f = NkResizeFilter::NK_BILINEAR) const noexcept;

			/**
			 * Reduit l'image d'un facteur EXACTEMENT 2 par moyenne de blocs 2x2.
			 * Rend la nouvelle image PAR VALEUR ; *this n'est pas modifiee.
			 *
			 * C'est le niveau de mipmap suivant, et pas un `Resize(w/2, h/2)` :
			 * `Resize` interpole en bilineaire (deux echantillons par axe), ce qui
			 * n'est PAS la moyenne des quatre pixels d'origine. Un niveau de mipmap
			 * se juge sur cette moyenne — c'est aussi ce que produit le GPU quand il
			 * genere la chaine lui-meme, donc precalculer avec ce filtre ne change
			 * pas l'image, seulement le moment ou elle est calculee.
			 *
			 * Dimensions impaires : la regle usuelle des mipmaps, `max(1, n / 2)`.
			 * La colonne (ou la ligne) surnumeraire est repliee sur la derniere,
			 * ce qui evite d'oublier le bord.
			 *
			 * @return L'image reduite, ou une image INVALIDE si *this l'est ou si
			 *         elle mesure deja 1x1 (il n'y a pas de niveau suivant).
			 */
			NkImage ReduceHalf() const noexcept;

			/**
			 * Copie (blit) l'image `src` entière dans *this à la position (dstX, dstY).
			 * Les deux images doivent avoir le même format pixel.
			 * Les débordements sont clippés silencieusement.
			 *
			 * @param src   Image source (image entière).
			 * @param dstX  Colonne de destination dans *this.
			 * @param dstY  Ligne de destination dans *this.
			 */
			void Blit(const NkImage &src, int32 dstX, int32 dstY) noexcept;

			/**
			 * Copie (blit) une sous-région de `src` dans une sous-région de *this,
			 * avec redimensionnement optionnel par interpolation bilinéaire.
			 *
			 * Cette méthode est la version la plus générale du blit :
			 *
			 *   - Si srcRegion est vide (width==0 && height==0), toute l'image src est utilisée.
			 *   - Si dstRegion est vide (width==0 && height==0), les pixels sont copiés
			 *     à partir de (dstRegion.left, dstRegion.top) sans redimensionnement
			 *     (équivalent à Blit avec région source).
			 *   - Si srcRegion et dstRegion ont des dimensions différentes, la région
			 *     source est redimensionnée par interpolation bilinéaire pour s'adapter
			 *     exactement à la région de destination.  Cela permet de faire du scaling
			 *     ciblé sur une zone précise sans créer d'image intermédiaire.
			 *
			 * Pré-conditions :
			 *   - *this et src doivent être valides (IsValid()==true).
			 *   - *this et src doivent avoir le même format pixel.
			 *
			 * Comportement des débordements :
			 *   - Les régions source et destination sont clippées aux bornes de leurs
			 *     images respectives avant toute opération.
			 *   - Si après clipping il ne reste rien à copier, la méthode retourne true
			 *     sans effectuer de travail (pas une erreur).
			 *
			 * Exemple d'utilisation :
			 * @code
			 *   // Colle le sprite src[10,20,64,64] dans atlas[100,200,128,128]
			 *   // en l'étirant (scale 1:2 sur chaque axe) :
			 *   atlas.BlitRegion(sprite,
			 *       math::NkIntRect{10, 20, 64, 64},   // srcRegion
			 *       math::NkIntRect{100, 200, 128, 128} // dstRegion
			 *   );
			 * @endcode
			 *
			 * @param src        Image source.
			 * @param srcRegion  Sous-région rectangulaire à lire dans src.
			 *                   Si width==0 && height==0 : toute l'image src.
			 * @param dstRegion  Sous-région rectangulaire de destination dans *this.
			 *                   Si width==0 && height==0 : copie sans redimensionnement
			 *                   à partir de (dstRegion.left, dstRegion.top).
			 * @return true si l'opération s'est terminée sans erreur.
			 *         false si les images sont invalides ou si les formats diffèrent.
			 */
			bool BlitRegion(const NkImage &src, const math::NkIntRect &srcRegion,
							const math::NkIntRect &dstRegion) noexcept;

			bool BlitRegion(const NkImage &src, const math::NkIntRect &srcRegion, const math::NkIntRect &dstRegion,
							NkResizeFilter filter) noexcept;

			/**
			 * Rend une sous-région comme nouvelle image, PAR VALEUR ; *this intacte.
			 * Les coordonnées doivent être entièrement dans les bornes.
			 *
			 * @param x, y  Coin supérieur gauche de la région.
			 * @param w, h  Dimensions de la région.
			 * @return La sous-région, ou une image INVALIDE si hors bornes.
			 */
			NkImage Crop(int32 x, int32 y, int32 w, int32 h) const noexcept;

			// ── Copies ────────────────────────────────────────────────────────────────

			/**
			 * Clone profond, rendu PAR VALEUR : mêmes pixels, même format.
			 * Ne touche pas à *this ; le clone est rendu PAR VALEUR.
			 *
			 * @return Le clone, ou une image INVALIDE si *this l'est.
			 */
			NkImage Copy() const noexcept;

			/**
			 * Copie une région de `src` dans *this à la position (dstX, dstY).
			 * API instance — opère sur *this, ne fait aucune allocation.
			 *
			 * Pré-conditions :
			 *   - *this et src doivent être valides (IsValid()==true).
			 *   - *this et src doivent avoir le même format pixel.
			 *   - *this doit être suffisamment grand pour accueillir la région.
			 *
			 * @param src   Image source.
			 * @param dstX  Colonne de destination dans *this.
			 * @param dstY  Ligne de destination dans *this.
			 * @param area  Région rectangulaire à copier dans src (NkIntRect).
			 *              Si area.width==0 && area.height==0, copie l'image entière.
			 * @param clip  true  → les débordements sont clippés silencieusement.
			 *              false → retourne false si quoi que ce soit sort des bornes.
			 * @return true si la copie a réussi (ou n'avait rien à faire après clip).
			 */
			bool Copy(const NkImage &src, int32 dstX, int32 dstY, const math::NkIntRect &area,
					  bool clip = true) noexcept;

			/**
			 * Copie *this dans une image existante `dst` sans allocation.
			 * Exige : même format ET mêmes dimensions.  Ne modifie pas dst en cas d'échec.
			 *
			 * @return true si la copie a réussi.
			 */
			bool CopyTo(NkImage &dst) const noexcept;

			/**
			 * Retourne un clone éventuellement converti vers `fmt`.
			 * Si fmt == mFormat, équivalent à Copy() (pas de conversion inutile).
			 * Ne touche pas à *this ; le clone est rendu PAR VALEUR.
			 *
			 * @return Le clone converti, ou une image INVALIDE si *this l'est ou fmt inconnu.
			 */
			NkImage CopyAs(NkImagePixelFormat fmt) const noexcept;

			// ── Accès aux métadonnées ─────────────────────────────────────────────────

			NKIMG_INLINE uint8 *Pixels() noexcept {
				return mPixels;
			}

			NKIMG_INLINE const uint8 *Pixels() const noexcept {
				return mPixels;
			}

			NKIMG_INLINE int32 Width() const noexcept {
				return mWidth;
			}

			NKIMG_INLINE int32 Height() const noexcept {
				return mHeight;
			}

			NKIMG_INLINE int32 Channels() const noexcept {
				return ChannelsOf(mFormat);
			}

			NKIMG_INLINE int32 BytesPP() const noexcept {
				return BytesPerPixelOf(mFormat);
			}

			NKIMG_INLINE int32 Stride() const noexcept {
				return mStride;
			}

			NKIMG_INLINE NkImagePixelFormat Format() const noexcept {
				return mFormat;
			}

			NKIMG_INLINE NkImageFormat SourceFormat() const noexcept {
				return mSrcFmt;
			}

			/** Retourne true si l'image contient des pixels valides. [NKIResource] */
			NKIMG_INLINE bool IsValid() const noexcept override {
				return mPixels && mWidth > 0 && mHeight > 0;
			}

			/** Retourne true si le format pixel est flottant (HDR). */
			NKIMG_INLINE bool IsHDR() const noexcept {
				return mFormat == NkImagePixelFormat::NK_RGBA128F || mFormat == NkImagePixelFormat::NK_RGB96F;
			}

			/** Taille totale du buffer pixel en octets (stride * height). */
			NKIMG_INLINE usize TotalBytes() const noexcept {
				return usize(mStride) * mHeight;
			}

			/** Pointeur vers le début de la ligne y (tient compte du stride). */
			NKIMG_INLINE uint8 *RowPtr(int32 y) noexcept {
				return mPixels + usize(y) * mStride;
			}

			NKIMG_INLINE const uint8 *RowPtr(int32 y) const noexcept {
				return mPixels + usize(y) * mStride;
			}

			// ── Dessin CPU (rasterisation logicielle dans le buffer pixel) ────────────
			//    Formats LDR 8-bit (RGBA/RGB/RG/R). No-op si image invalide, hors
			//    bornes, ou HDR. Couleur = math::NkColor (= NkColor2D). SetPixel ECRASE
			//    (pas de blending) ; BlendPixel fait un src-over alpha.

			/** Ecrit un pixel (ecrase). Clamp aux bornes (no-op si hors image). */
			NKIMG_INLINE void SetPixel(int32 x, int32 y, const math::NkColor &c) noexcept {
				if (!mPixels || x < 0 || y < 0 || x >= mWidth || y >= mHeight || IsHDR())
					return;
				uint8 *p = RowPtr(y) + usize(x) * BytesPP();
				const int32 ch = Channels();
				if (ch >= 1)
					p[0] = c.r;
				if (ch >= 2)
					p[1] = c.g;
				if (ch >= 3)
					p[2] = c.b;
				if (ch >= 4)
					p[3] = c.a;
			}

			/** Lit un pixel. Retourne (0,0,0,0) si hors bornes / invalide / HDR. */
			NKIMG_INLINE math::NkColor GetPixel(int32 x, int32 y) const noexcept {
				if (!mPixels || x < 0 || y < 0 || x >= mWidth || y >= mHeight || IsHDR())
					return math::NkColor(0, 0, 0, 0);
				const uint8 *p = RowPtr(y) + usize(x) * BytesPP();
				const int32 ch = Channels();
				const uint8 r = ch >= 1 ? p[0] : uint8(0);
				const uint8 g = ch >= 2 ? p[1] : r;
				const uint8 b = ch >= 3 ? p[2] : r;
				const uint8 a = ch >= 4 ? p[3] : uint8(255);
				return math::NkColor(r, g, b, a);
			}

			/** Composite src-over (respecte l'alpha de `c`) sur le pixel existant. */
			NKIMG_INLINE void BlendPixel(int32 x, int32 y, const math::NkColor &c) noexcept {
				if (c.a == 255) {
					SetPixel(x, y, c);
					return;
				}
				if (c.a == 0)
					return;
				const math::NkColor d = GetPixel(x, y);
				const uint32 a = c.a, ia = 255u - a;
				SetPixel(x, y,
						 math::NkColor(uint8((c.r * a + d.r * ia) / 255u), uint8((c.g * a + d.g * ia) / 255u),
									   uint8((c.b * a + d.b * ia) / 255u), uint8(a + d.a * ia / 255u)));
			}

			/** Remplit toute l'image avec `c`. */
			NKIMG_INLINE void Fill(const math::NkColor &c) noexcept {
				for (int32 y = 0; y < mHeight; ++y)
					for (int32 x = 0; x < mWidth; ++x)
						SetPixel(x, y, c);
			}

			/** Ligne horizontale [x0..x1] a la hauteur y. */
			NKIMG_INLINE void DrawHLine(int32 x0, int32 x1, int32 y, const math::NkColor &c) noexcept {
				if (x0 > x1) {
					const int32 t = x0;
					x0 = x1;
					x1 = t;
				}
				for (int32 x = x0; x <= x1; ++x)
					SetPixel(x, y, c);
			}

			/** Ligne verticale [y0..y1] a l'abscisse x. */
			NKIMG_INLINE void DrawVLine(int32 x, int32 y0, int32 y1, const math::NkColor &c) noexcept {
				if (y0 > y1) {
					const int32 t = y0;
					y0 = y1;
					y1 = t;
				}
				for (int32 y = y0; y <= y1; ++y)
					SetPixel(x, y, c);
			}

			/** Ligne quelconque (algorithme de Bresenham). */
			NKIMG_INLINE void DrawLine(int32 x0, int32 y0, int32 x1, int32 y1, const math::NkColor &c) noexcept {
				const int32 dx = x1 > x0 ? x1 - x0 : x0 - x1;
				const int32 dy = y1 > y0 ? y1 - y0 : y0 - y1;
				const int32 sx = x0 < x1 ? 1 : -1;
				const int32 sy = y0 < y1 ? 1 : -1;
				int32 err = dx - dy;
				for (;;) {
					SetPixel(x0, y0, c);
					if (x0 == x1 && y0 == y1)
						break;
					const int32 e2 = err << 1;
					if (e2 > -dy) {
						err -= dy;
						x0 += sx;
					}
					if (e2 < dx) {
						err += dx;
						y0 += sy;
					}
				}
			}

			/** Contour de rectangle (x,y,w,h). */
			NKIMG_INLINE void DrawRect(int32 x, int32 y, int32 w, int32 h, const math::NkColor &c) noexcept {
				if (w <= 0 || h <= 0)
					return;
				DrawHLine(x, x + w - 1, y, c);
				DrawHLine(x, x + w - 1, y + h - 1, c);
				DrawVLine(x, y, y + h - 1, c);
				DrawVLine(x + w - 1, y, y + h - 1, c);
			}

			/** Rectangle plein (x,y,w,h). */
			NKIMG_INLINE void FillRect(int32 x, int32 y, int32 w, int32 h, const math::NkColor &c) noexcept {
				for (int32 j = 0; j < h; ++j)
					DrawHLine(x, x + w - 1, y + j, c);
			}

			/** Contour de cercle (centre cx,cy, rayon r) — midpoint. */
			NKIMG_INLINE void DrawCircle(int32 cx, int32 cy, int32 r, const math::NkColor &c) noexcept {
				if (r < 0)
					return;
				int32 x = r, y = 0, err = 1 - r;
				while (x >= y) {
					SetPixel(cx + x, cy + y, c);
					SetPixel(cx + y, cy + x, c);
					SetPixel(cx - y, cy + x, c);
					SetPixel(cx - x, cy + y, c);
					SetPixel(cx - x, cy - y, c);
					SetPixel(cx - y, cy - x, c);
					SetPixel(cx + y, cy - x, c);
					SetPixel(cx + x, cy - y, c);
					++y;
					if (err < 0) {
						err += 2 * y + 1;
					} else {
						--x;
						err += 2 * (y - x) + 1;
					}
				}
			}

			/** Disque plein (centre cx,cy, rayon r) — scanlines. */
			NKIMG_INLINE void FillCircle(int32 cx, int32 cy, int32 r, const math::NkColor &c) noexcept {
				if (r < 0)
					return;
				for (int32 dy = -r; dy <= r; ++dy) {
					const int32 dx = int32(math::NkSqrt(float32(r * r - dy * dy)));
					DrawHLine(cx - dx, cx + dx, cy + dy, c);
				}
			}

			/** Contour d'ellipse (centre cx,cy, demi-axes rx,ry) — parametrique. */
			NKIMG_INLINE void DrawEllipse(int32 cx, int32 cy, int32 rx, int32 ry, const math::NkColor &c) noexcept {
				if (rx <= 0 || ry <= 0)
					return;
				const int32 steps = (rx + ry) < 8 ? 16 : (rx + ry) * 2;
				int32 px = cx + rx, py = cy;
				for (int32 i = 1; i <= steps; ++i) {
					const float32 a = (float32(i) / float32(steps)) * 6.28318530718f;
					const int32 nx = cx + int32(float32(rx) * math::NkCos(a));
					const int32 ny = cy + int32(float32(ry) * math::NkSin(a));
					DrawLine(px, py, nx, ny, c);
					px = nx;
					py = ny;
				}
			}

			/** Ellipse pleine (centre cx,cy, demi-axes rx,ry) — scanlines. */
			NKIMG_INLINE void FillEllipse(int32 cx, int32 cy, int32 rx, int32 ry, const math::NkColor &c) noexcept {
				if (rx <= 0 || ry <= 0)
					return;
				for (int32 dy = -ry; dy <= ry; ++dy) {
					const float32 t = 1.0f - (float32(dy * dy) / float32(ry * ry));
					if (t < 0.0f)
						continue;
					const int32 dx = int32(float32(rx) * math::NkSqrt(t));
					DrawHLine(cx - dx, cx + dx, cy + dy, c);
				}
			}

			// ── Gestion mémoire ───────────────────────────────────────────────────────


			/**
			 * [NKIResource] Libère les pixels (si owning) et remet *this dans l'état
			 * « image vide », réutilisable ensuite (un Load ultérieur repart proprement).
			 * Sûr sur une instance pile comme heap : c'est l'opération de « déchargement »
			 * réutilisable (un Load ultérieur réinitialise *this proprement).
			 */
			void Unload() noexcept override;

			// ── Fabriques bas niveau (usage interne / codecs) ─────────────────────────

			/**
			 * Alloue une image vide (pixels zeroed) de dimensions (w × h) et de format fmt.
			 * Utilisé par les codecs pour construire leur résultat.
			 * Le résultat est rendu par valeur et se détruit tout seul.
			 */
			static NkImage Alloc(int32 w, int32 h, NkImagePixelFormat fmt) noexcept;

			/**
			 * Crée une vue non-owning sur un buffer pixel externe.
			 * Le buffer n'est PAS libéré par le destructeur (vue non-owning).
			 * L'appelant reste responsable de la durée de vie du buffer.
			 *
			 * @param pixels  Pointeur vers les données pixel.
			 * @param w, h    Dimensions de l'image.
			 * @param fmt     Format pixel.
			 * @param stride  Stride en octets (0 = calculé automatiquement w*bpp).
			 */
			static NkImage Wrap(uint8 *pixels, int32 w, int32 h, NkImagePixelFormat fmt, int32 stride = 0) noexcept;

			/**
			 * Tone-mapping d'une image HDR (RGB96F/RGBA128F) vers RGBA32 LDR.
			 * Applique : pixel_ldr = pow(clamp(pixel_hdr * exposure), 1/gamma) * 255.
			 *
			 * @param hdrImage  Image source HDR (doit être IsHDR()==true).
			 * @param exposure  Facteur d'exposition (défaut 1.0).
			 * @param gamma     Gamma de correction (défaut 2.2, sRGB standard).
			 * @return L'image RGBA32, ou une image INVALIDE si hdrImage l'est.
			 */
			static NkImage ConvertToTexture(const NkImage &hdrImage, float exposure = 1.0f,
											 float gamma = 2.2f) noexcept;

		private:
			// ── Données membres ───────────────────────────────────────────────────────

			uint8 *mPixels = nullptr;									 ///< Buffer pixel.
			int32 mWidth = 0;											 ///< Largeur en pixels.
			int32 mHeight = 0;											 ///< Hauteur en pixels.
			int32 mStride = 0;											 ///< Bytes par ligne (aligné 4).
			NkImagePixelFormat mFormat = NkImagePixelFormat::NK_UNKNOWN; ///< Format pixel.
			NkImageFormat mSrcFmt = NkImageFormat::NK_UNKNOWN;			 ///< Format du fichier source.
			bool mOwning = true; ///< Si false, le destructeur ne libère pas mPixels.

			// ── Helpers privés ────────────────────────────────────────────────────────

			/**
			 * Détecte le format du fichier image depuis les magic bytes.
			 * Inspecte les premiers octets du buffer pour identifier PNG, JPEG, BMP, etc.
			 * Retourne NK_UNKNOWN si non reconnu.
			 */
			static NkImageFormat DetectFormat(const uint8 *data, usize size) noexcept;

			/**
			 * Dispatch vers le codec approprié selon le format détecté.
			 * Si `desired` > 0 et différent du format natif, convertit après décodage.
			 */
			static NkImage Dispatch(const uint8 *data, usize size, int32 desired, NkImageFormat fmt) noexcept;

			/**
			 * Conversion bas niveau de canaux pour des données pixel brutes.
			 * Gère toutes les combinaisons (1→4, 4→1, 3→4, etc.) via luminance perceptuelle.
			 * Alloue le buffer de destination (aligné 4 octets par ligne).
			 *
			 * @param src       Buffer source.
			 * @param w, h      Dimensions de l'image.
			 * @param srcCh     Nombre de canaux sources.
			 * @param dstCh     Nombre de canaux cibles.
			 * @param srcStride Stride source en octets.
			 * @return Buffer destination alloué via nkCalloc, ou nullptr en cas d'échec.
			 */
			static uint8 *ConvertChannels(const uint8 *src, int32 w, int32 h, int32 srcCh, int32 dstCh,
										  int32 srcStride) noexcept;

			/**
			 * Helper interne partagé par Load() et LoadFromMemory() (API instance).
			 * Charge depuis un buffer mémoire déjà lu, stocke le résultat dans *this.
			 * Libère l'ancien buffer avant de remplir *this.
			 */
			bool LoadFromMemoryImpl(const uint8 *data, usize size, int32 desiredChannels) noexcept;

			/**
			 * Noyau interne de BlitRegion : copie une sous-région de src (déjà validée
			 * et clippée) dans *this sans redimensionnement.
			 * Appelé par BlitRegion quand les dimensions src et dst sont identiques.
			 *
			 * @param src    Image source.
			 * @param sx,sy  Coin supérieur gauche dans src (déjà clippé, >= 0).
			 * @param sw,sh  Dimensions à copier (déjà clippées, > 0).
			 * @param dx,dy  Coin supérieur gauche dans *this (déjà clippé, >= 0).
			 */
			void BlitRegionDirect(const NkImage &src, int32 sx, int32 sy, int32 sw, int32 sh, int32 dx,
								  int32 dy) noexcept;

			/**
			 * Noyau interne de BlitRegion : copie une sous-région de src dans une
			 * sous-région de *this avec redimensionnement bilinéaire.
			 * Appelé par BlitRegion quand les dimensions src et dst diffèrent.
			 *
			 * @param src         Image source.
			 * @param sx,sy,sw,sh Région source (clippée, > 0).
			 * @param dx,dy,dw,dh Région de destination (clippée, > 0).
			 */
			void BlitRegionScaled(const NkImage &src, int32 sx, int32 sy, int32 sw, int32 sh, int32 dx, int32 dy,
								  int32 dw, int32 dh) noexcept;

			// ── Accès ami pour les codecs ─────────────────────────────────────────────
			// Les codecs accèdent aux membres privés (mPixels, mFormat, etc.)
			// pour construire leur résultat via Alloc() et affecter mSrcFmt.

			friend class NkPNGCodec;
			friend class NkJPEGCodec;
			friend class NkBMPCodec;
			friend class NkTGACodec;
			friend class NkHDRCodec;
			friend class NkPPMCodec;
			friend class NkQOICodec;
			friend class NkGIFCodec;
			friend class NkICOCodec;
			friend class NkEXRCodec;
	};

	// ─────────────────────────────────────────────────────────────────────────────
	//  NkImageStream
	// ─────────────────────────────────────────────────────────────────────────────

	/**
	 * @class NkImageStream
	 *
	 * Buffer de lecture/écriture binaire utilisé par les codecs d'images.
	 *
	 * MODE LECTURE :
	 *   Construit avec (data, size), expose Read*, Skip, Seek.
	 *   Les lectures hors bornes positionnent mError=true et retournent 0/zéro.
	 *
	 * MODE ÉCRITURE :
	 *   Construit sans arguments, expose Write*.
	 *   Croît dynamiquement via nkRealloc (doublage de capacité).
	 *   Appeler TakeBuffer() pour récupérer le buffer final.
	 *
	 * ENDIANNESS :
	 *   - BE (Big Endian)   : PNG, JPEG (réseau)
	 *   - LE (Little Endian): BMP, TGA, QOI, EXR
	 *
	 * MÉMOIRE :
	 *   Le buffer d'écriture est alloué via NkAlloc.
	 *   Après TakeBuffer(), l'appelant est responsable de le libérer avec NkFree.
	 */
	class NKENTSEU_IMAGE_API NkImageStream {
		public:
			/** Constructeur lecture : pointe sur un buffer existant (non owning). */
			NkImageStream(const uint8 *data, usize size) noexcept : mRdData(data), mRdSize(size) {
			}

			/** Constructeur écriture : buffer dynamique initialement vide. */
			NkImageStream() noexcept {
			}

			~NkImageStream() noexcept {
			}

			// ── Lecture ───────────────────────────────────────────────────────────────

			uint8 ReadU8() noexcept;	 ///< Lit 1 octet non signé.
			uint16 ReadU16BE() noexcept; ///< Lit 2 octets big-endian non signés.
			uint16 ReadU16LE() noexcept; ///< Lit 2 octets little-endian non signés.
			uint32 ReadU32BE() noexcept; ///< Lit 4 octets big-endian non signés.
			uint32 ReadU32LE() noexcept; ///< Lit 4 octets little-endian non signés.
			int16 ReadI16BE() noexcept;	 ///< Lit 2 octets big-endian signés.
			int32 ReadI32LE() noexcept;	 ///< Lit 4 octets little-endian signés.

			/** Lit `n` octets dans `dst` (peut être nullptr pour avancer le curseur). */
			usize ReadBytes(uint8 *dst, usize n) noexcept;

			/** Avance le curseur de `n` octets. */
			void Skip(usize n) noexcept;

			/** Positionne le curseur à l'offset `pos` depuis le début. */
			void Seek(usize pos) noexcept;

			// ── Accesseurs lecture ────────────────────────────────────────────────────

			usize Tell() const noexcept {
				return mRdPos;
			}

			usize Size() const noexcept {
				return mRdSize;
			}

			bool IsEOF() const noexcept {
				return mRdPos >= mRdSize;
			}

			bool HasBytes(usize n) const noexcept {
				return mRdPos + n <= mRdSize;
			}

			bool HasError() const noexcept {
				return mError;
			}

			/** Pointeur vers la position de lecture courante. */
			const uint8 *Ptr() const noexcept {
				return mRdData + mRdPos;
			}

			// ── Écriture ──────────────────────────────────────────────────────────────

			bool WriteU8(uint8 v) noexcept;						 ///< Écrit 1 octet.
			bool WriteU16BE(uint16 v) noexcept;					 ///< Écrit 2 octets big-endian.
			bool WriteU16LE(uint16 v) noexcept;					 ///< Écrit 2 octets little-endian.
			bool WriteU32BE(uint32 v) noexcept;					 ///< Écrit 4 octets big-endian.
			bool WriteU32LE(uint32 v) noexcept;					 ///< Écrit 4 octets little-endian.
			bool WriteI32LE(int32 v) noexcept;					 ///< Écrit 4 octets little-endian signés.
			bool WriteBytes(const uint8 *src, usize n) noexcept; ///< Écrit n octets.

			/**
			 * Transfère la propriété du buffer d'écriture vers l'appelant.
			 * Après l'appel, le stream ne possède plus le buffer (mWrBuf=null).
			 * L'appelant DOIT libérer outData avec NkFree.
			 *
			 * @param outData  Reçoit le pointeur vers les données écrites.
			 * @param outSize  Reçoit la taille en octets.
			 * @return true si le buffer était non-null.
			 */
			bool TakeBuffer(uint8 *&outData, usize &outSize) noexcept {
				outData = mWrBuf;
				outSize = mWrSize;
				mWrBuf = nullptr;
				mWrSize = 0;
				mWrCap = 0;
				return outData != nullptr;
			}

			/** Taille actuelle du buffer d'écriture en octets. */
			usize WriteSize() const noexcept {
				return mWrSize;
			}

		private:
			// Lecture
			const uint8 *mRdData = nullptr; ///< Buffer source (non owning).
			usize mRdSize = 0;				///< Taille du buffer source.
			usize mRdPos = 0;				///< Curseur de lecture.
			bool mError = false;			///< true si une lecture hors bornes s'est produite.

			// Écriture
			uint8 *mWrBuf = nullptr; ///< Buffer dynamique (owning, alloué via NkAlloc).
			usize mWrSize = 0;		 ///< Octets effectivement écrits.
			usize mWrCap = 0;		 ///< Capacité totale du buffer.

			/**
			 * Croît le buffer d'écriture pour accueillir `needed` octets supplémentaires.
			 * Stratégie : doublage de capacité à partir de 4096 octets.
			 * @return true si le realloc a réussi.
			 */
			bool Grow(usize needed) noexcept;
	};

	// ─────────────────────────────────────────────────────────────────────────────
	//  NkDeflate — inflate / deflate (adapté de stb_image v2.16, public domain)
	// ─────────────────────────────────────────────────────────────────────────────

	/**
	 * @class NkDeflate
	 *
	 * Implémentation inflate (décompression DEFLATE RFC 1951 + zlib RFC 1950)
	 * et deflate RÉEL (un bloc Huffman FIXE, BTYPE=01, + LZ77), pour permettre
	 * l'écriture de PNG valides.
	 *
	 * ⚠️ CE PARAGRAPHE DISAIT LE CONTRAIRE DU CODE : « deflate minimal
	 *  (compression sans compression = stored blocks) ». Ce n'est plus vrai
	 *  depuis que Compress() écrit du Huffman fixe + LZ77 (NkImage.cpp, section
	 *  « DEFLATE réel : UN bloc Huffman FIXE (BTYPE=01) + LZ77 »). Mesure du
	 *  2026-09-13 sur des maillages : x3,86 sur 448 octets, x2,02 sur 9 240,
	 *  x1,22 sur 317 856 — le niveau d'un zlib -6 sur les petits volumes. Un lot
	 *  entier a failli être écrit pour « ajouter un compresseur au dépôt » sur la
	 *  foi de cette phrase. Une documentation est un instrument : quand elle ment,
	 *  elle coûte autant qu'un témoin muet.
	 *
	 * ─── CORRECTNESS INFLATE (LSB-first, stb_image exact) ────────────────────
	 *
	 *  DEFLATE est LSB-first : le premier bit du premier code est dans le bit 0
	 *  du premier octet.  L'accumulation des bits se fait de gauche à droite
	 *  dans un registre 32 bits :
	 *
	 *    bits |= byte << nbits    (fill_bits : accumule par le MSB du registre)
	 *    v = bits & mask          (receive    : extrait par le LSB du registre)
	 *    bits >>= n               (consume    : décale vers le bas)
	 *
	 *  La fast table Huffman est indexée directement par les `FAST` bits LSB
	 *  du registre (qui correspondent à `FAST` bits bit-reversed dans l'espace
	 *  des codes Huffman canoniques).
	 *
	 * ─── FIX CRITIQUE : en-tête zlib (CMF/FLG) ──────────────────────────────
	 *
	 *  zlib RFC 1950 : CMF = in[0], FLG = in[1].
	 *  FDICT = bit 5 de FLG (in[1]), PAS bit 5 de CMF (in[0]).
	 *
	 *  CMF=0x78 (le plus courant pour les PNG : niveau 6 ou 9) a TOUJOURS
	 *  le bit 5 à 1 (CINFO=7 dans le nibble haut).  L'ancienne version qui
	 *  testait if(in[0] & 0x20) rejetait donc TOUS les PNG standard :
	 *    0x78 0x9C  (compression défaut)
	 *    0x78 0xDA  (compression maximum)
	 *    0x78 0x5E  (compression rapide)
	 *    0x78 0x01  (sans compression)
	 *
	 *  Correction : if(flg & 0x20) où flg = in[1].
	 */
	class NKENTSEU_IMAGE_API NkDeflate {
		public:
			/**
			 * Décompresse un flux zlib RFC 1950 (avec en-tête CMF/FLG et checksum Adler-32).
			 * Utilisé pour décoder les blocs IDAT des PNG.
			 *
			 * @param in      Buffer compressé.
			 * @param inSz    Taille du buffer compressé.
			 * @param out     Buffer de sortie pré-alloué.
			 * @param outCap  Capacité du buffer de sortie.
			 * @param written Nombre d'octets effectivement écrits dans out.
			 * @return true si la décompression a réussi sans erreur.
			 */
			static bool Decompress(const uint8 *in, usize inSz, uint8 *out, usize outCap, usize &written) noexcept;

			/**
			 * Décompresse un flux DEFLATE brut RFC 1951 (sans en-tête zlib ni checksum).
			 * Utilisé pour les formats qui embarquent du DEFLATE brut (ex: ZIP, gzip).
			 */
			static bool DecompressRaw(const uint8 *in, usize inSz, uint8 *out, usize outCap, usize &written) noexcept;

			/**
			 * Compresse les données en zlib RFC 1950, par UN bloc Huffman FIXE
			 * (BTYPE=01) + LZ77. Produit un flux zlib valide lisible par tout
			 * décompresseur standard, et il COMPRESSE VRAIMENT — la description
			 * « stored blocks, ratio 1:1 » qui tenait ici était périmée et a induit
			 * en erreur (cf. l'avertissement sur la classe).
			 *
			 * @param in      Données à compresser.
			 * @param inSz    Taille des données.
			 * @param outData Reçoit le buffer zlib alloué (NkAlloc).  L'appelant doit NkFree.
			 * @param outSz   Reçoit la taille du buffer de sortie.
			 * @param level   Niveau demandé — IGNORÉ : la table de Huffman est fixe,
			 *                il n'y a pas de niveaux. Gardé pour la forme d'appel.
			 * @return true si l'encodage a réussi.
			 */
			static bool Compress(const uint8 *in, usize inSz, uint8 *&out, usize &outSz, int32 level = 6) noexcept;

		private:
			// ── Table Huffman (stb_image stbi__zhuffman) ──────────────────────────────
			/**
			 * Structure d'une table de décodage Huffman canonique.
			 * Combinaison d'une LUT rapide (FAST=9 bits, O(1) pour 99% des codes)
			 * et d'un slow path basé sur un tableau maxcode[] pré-shifté.
			 */
			struct ZHuff {
					static constexpr int32 FAST = 9; ///< Taille de la fast table (bits).
					uint16 fast[1 << FAST];			 ///< fast[idx] = (longueur<<9)|symbole, 0=non utilisé.
					uint16 firstcode[16];			 ///< Premier code canonique pour chaque longueur.
					int32 maxcode[17];				 ///< Limite supérieure (pré-shiftée 16-l) pour chaque longueur.
					uint16 firstsym[16];			 ///< Premier symbole pour chaque longueur dans sizes[]/values[].
					uint8 sizes[288];				 ///< Longueur de code pour chaque symbole (trié par code).
					uint16 values[288];				 ///< Symbole correspondant (trié par code).
			};

			// ── Contexte inflate ──────────────────────────────────────────────────────
			/**
			 * État complet d'un décodage inflate en cours.
			 * Stocke le registre de bits, le buffer de sortie et la position courante.
			 */
			struct ZBuf {
					const uint8 *data; ///< Buffer compressé.
					usize size;		   ///< Taille du buffer compressé.
					usize pos;		   ///< Position de lecture courante (octets).
					uint32 bits;	   ///< Registre de bits accumulés (LSB-first).
					int32 nbits;	   ///< Nombre de bits valides dans `bits`.
					bool err;		   ///< true si une erreur irrécouvrable s'est produite.
					uint8 *out;		   ///< Buffer de sortie (pré-alloué par l'appelant).
					usize outCap;	   ///< Capacité du buffer de sortie.
					usize outPos;	   ///< Position d'écriture courante dans le buffer de sortie.
					int32 eofZeros;	   ///< Octets de zéros injectés après la fin du flux (voir zFill).
			};

			// ── Primitives inflate ────────────────────────────────────────────────────

			/** Remplit le registre de bits depuis le flux compressé (au moins 25 bits). */
			static void zFill(ZBuf &z) noexcept;

			/** Extrait et consomme `n` bits depuis le registre (LSB-first). */
			static uint32 zBits(ZBuf &z, int32 n) noexcept;

			/**
			 * Construit une table Huffman depuis une liste de longueurs de codes.
			 * Gère la fast table (bit-reverse du code pour l'indexation directe)
			 * et la slow table (firstcode, maxcode, firstsym, sizes, values).
			 *
			 * @param h      Table à construire.
			 * @param szList Liste des longueurs de codes (une par symbole).
			 * @param num    Nombre de symboles.
			 * @return false si la liste est invalide (longueurs incohérentes).
			 */
			static bool zBuildH(ZHuff &h, const uint8 *szList, int32 num) noexcept;

			/**
			 * Décode un symbole Huffman depuis le registre de bits.
			 * Fast path O(1) pour les codes <= FAST bits.
			 * Slow path O(longueur) pour les codes plus longs.
			 * @return Symbole décodé, ou -1 si erreur.
			 */
			static int32 zDecode(ZBuf &z, const ZHuff &h) noexcept;

			/** Entrée principale inflate : parse l'en-tête zlib si hdr==true, puis les blocs. */
			static bool zInflate(ZBuf &z, bool parseHdr) noexcept;

			/** Décode un bloc DEFLATE : lit BFINAL et BTYPE, dispatch vers le type. */
			static bool zBlock(ZBuf &z, bool &last) noexcept;

			/** Décode un bloc Huffman (types 1 fixed et 2 dynamic). */
			static bool zHuffBlock(ZBuf &z, const ZHuff &zl, const ZHuff &zd) noexcept;

			/** Décode un bloc non-compressé (BTYPE=00) : copie len octets verbatim. */
			static bool zStored(ZBuf &z) noexcept;

			/** Décode un bloc à codes fixes (BTYPE=01, tables RFC 1951 hardcodées). */
			static bool zFixed(ZBuf &z) noexcept;

			/** Décode un bloc à codes dynamiques (BTYPE=10, tables encodées dans le flux). */
			static bool zDynamic(ZBuf &z) noexcept;

			/**
			 * Calcule le checksum Adler-32.
			 * @param prev  Checksum initial (1 pour un nouveau calcul).
			 * @return Checksum Adler-32 mis à jour.
			 */
			static uint32 Adler32(const uint8 *data, usize size, uint32 prev = 1) noexcept;

			// ── Tables statiques DEFLATE (RFC 1951) ───────────────────────────────────

			static const uint16 kLenBase[29];  ///< Longueur de base pour les codes 257–285.
			static const uint8 kLenExtra[29];  ///< Bits extra pour les codes de longueur.
			static const uint16 kDistBase[30]; ///< Distance de base pour les codes 0–29.
			static const uint8 kDistExtra[30]; ///< Bits extra pour les codes de distance.
			static const uint8 kCLOrder[19];   ///< Ordre de lecture des longueurs CL (dynamic).
			static const uint8 kZDefLen[288];  ///< Longueurs des codes litéraux/longueur fixes.
			static const uint8 kZDefDist[32];  ///< Longueurs des codes de distance fixes.
	};

} // namespace nkentseu