#pragma once
// AUTEUR : TEUGUIA TADJUIDJE Rodolf Séderis — Rihen
// =============================================================================
// NkDX11Renderer2D.h — DirectX 11 2D renderer backend
// =============================================================================
#include "NKCanvas/Renderer/Batch/NkBatchRenderer2D.h"
#include "NKCanvas/Renderer/Resources/NkTexture.h"

#if defined(NKENTSEU_PLATFORM_WINDOWS)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <wrl/client.h>
#include <d3d11_1.h>
#include <d3dcompiler.h>
using Microsoft::WRL::ComPtr;

namespace nkentseu {
	namespace renderer {

		class NkDX11Renderer2D final : public NkBatchRenderer2D {
			public:
				NkDX11Renderer2D() = default;

				~NkDX11Renderer2D() override {
					if (IsValid())
						Shutdown();
				}

				bool Initialize(NkIGraphicsContext *ctx) override;
				void Shutdown() override;

				bool IsValid() const override {
					return mIsValid;
				}

				void Clear(const NkColor2D &col) override;

			protected:
				void BeginBackend() override;
				void EndBackend() override;
				void SubmitBatches(const NkBatchGroup *groups, uint32 groupCount, const NkVertex2D *verts,
								   uint32 vCount, const uint32 *idx, uint32 iCount) override;
				void UploadProjection(const float32 proj[16]) override;

				// ── Dispatch NkTexture (cf. NkTextureBackend.h) ──────────────────
				// Callbacks statiques utilises par NkTexture::Create/Update/...
				// pour gerer la ressource GPU cote backend DX11. Les 3 COM
				// pointers (texture/SRV/sampler) sont stockes dans une registry
				// globale indexee par l'ID 1-based retourne par Create.
				static uint32 CreateDX11Texture(uint32 w, uint32 h, const uint8 *rgba);
				static void UpdateDX11Texture(uint32 id, uint32 x, uint32 y, uint32 w, uint32 h, const uint8 *rgba);
				static void DeleteDX11Texture(uint32 id);
				static void SetDX11TextureFilter(uint32 id, NkTextureFilter f);
				static void SetDX11TextureWrap(uint32 id, NkTextureWrap w);

				// ── Dispatch NkRenderTexture (offscreen RTV+SRV) ──────────────────────
				// Cree un Texture2D RENDER_TARGET|SHADER_RESOURCE + RTV + une entry
				// texture (pour sampler le resultat). Bind bascule l'OMSetRenderTargets
				// vers l'offscreen (contexte immediat), Unbind restaure le back buffer.
				static uint32 CreateDX11RenderTexture(uint32 w, uint32 h);
				static void DestroyDX11RenderTexture(uint32 handle);
				static void BindDX11RenderTexture(uint32 handle);
				static void UnbindDX11RenderTexture();
				static uint32 GetDX11RenderTextureColorId(uint32 handle);

			private:
				bool CreateShaders();
				bool CreateBuffers();
				bool CreateStates();
				bool CreateWhiteTexture();
				void ApplyBlendMode(NkBlendMode mode);

				NkIGraphicsContext *mCtx = nullptr;
				bool mIsValid = false;

				ComPtr<ID3D11Device1> mDevice;
				ComPtr<ID3D11DeviceContext1> mDevCtx;

				ComPtr<ID3D11VertexShader> mVS;
				ComPtr<ID3D11PixelShader> mPS;
				ComPtr<ID3D11InputLayout> mInputLayout;

				ComPtr<ID3D11Buffer> mVB;	  // vertex buffer (dynamic)
				ComPtr<ID3D11Buffer> mIB;	  // index buffer (dynamic)
				ComPtr<ID3D11Buffer> mCBProj; // constant buffer: projection

				ComPtr<ID3D11BlendState> mBlendAlpha;
				ComPtr<ID3D11BlendState> mBlendAdd;
				ComPtr<ID3D11BlendState> mBlendMul;
				ComPtr<ID3D11BlendState> mBlendNone;
				// 2026-09-04 : Screen, Darken (MIN), Lighten (MAX), Plus Lighter -- exacts
				ComPtr<ID3D11BlendState> mBlendScreen;
				ComPtr<ID3D11BlendState> mBlendDarken;
				ComPtr<ID3D11BlendState> mBlendLighten;
				ComPtr<ID3D11BlendState> mBlendPlus;
				ComPtr<ID3D11RasterizerState> mRasterState;
				ComPtr<ID3D11DepthStencilState> mDSSState;
				ComPtr<ID3D11SamplerState> mSamplerLinear;
				ComPtr<ID3D11SamplerState> mSamplerNearest;

				ComPtr<ID3D11Texture2D> mWhiteTex;
				ComPtr<ID3D11ShaderResourceView> mWhiteSRV;

				NkBlendMode mLastBlend = NkBlendMode::NK_NONE;
		};

	} // namespace renderer
} // namespace nkentseu
#endif // WINDOWS