#pragma once
// AUTEUR : TEUGUIA TADJUIDJE Rodolf Séderis — Rihen
// =============================================================================
// NkDX12Renderer2D.h — DirectX 12 2D renderer backend
// Uses root constants for projection (no CBV heap needed for a 64-byte matrix).
// Dynamic ring buffer for VB/IB (double-buffered to avoid GPU/CPU stalls).
// =============================================================================
#include "NKCanvas/Renderer/Batch/NkBatchRenderer2D.h"
#include "NKCanvas/Renderer/Resources/NkTexture.h"
#include "NKCanvas/Renderer/Resources/NkTextureBackend.h"

#if defined(NKENTSEU_PLATFORM_WINDOWS)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <wrl/client.h>
#include <d3d12.h>
#include <dxgi1_6.h>
#include <d3dcompiler.h>
using Microsoft::WRL::ComPtr;

namespace nkentseu {
	namespace renderer {

		class NkDX12Renderer2D final : public NkBatchRenderer2D {
			public:
				NkDX12Renderer2D() = default;

				~NkDX12Renderer2D() override {
					if (IsValid())
						Shutdown();
				}

				bool Initialize(NkIGraphicsContext *ctx) override;
				void Shutdown() override;

				bool IsValid() const override {
					return mIsValid;
				}

				void Clear(const NkColor2D &col) override;

			protected:
				void BeginBackend() override;
				void EndBackend() override;
				void SubmitBatches(const NkBatchGroup *groups, uint32 groupCount, const NkVertex2D *verts,
								   uint32 vCount, const uint32 *idx, uint32 iCount) override;
				void UploadProjection(const float32 proj[16]) override;

			private:
				bool CreateRootSignature();
				bool CreatePSOs();
				bool CreateBuffers();
				bool CreateDescriptorHeap();
				bool CreateWhiteTexture();
				bool CreateSampler();

				void TransitionResource(ID3D12GraphicsCommandList4 *cmd, ID3D12Resource *res,
										D3D12_RESOURCE_STATES from, D3D12_RESOURCE_STATES to);

				NkIGraphicsContext *mCtx = nullptr;
				bool mIsValid = false;

				ComPtr<ID3D12Device5> mDevice;
				ComPtr<ID3D12GraphicsCommandList4> mCmdList;

				ComPtr<ID3D12RootSignature> mRootSig;
				ComPtr<ID3D12PipelineState> mPSOAlpha;
				ComPtr<ID3D12PipelineState> mPSOAdd;
				ComPtr<ID3D12PipelineState> mPSOMul;
				ComPtr<ID3D12PipelineState> mPSONone;
				// 2026-09-04 : Screen, Darken (MIN), Lighten (MAX), Plus Lighter -- exacts
				ComPtr<ID3D12PipelineState> mPSOScreen;
				ComPtr<ID3D12PipelineState> mPSODarken;
				ComPtr<ID3D12PipelineState> mPSOLighten;
				ComPtr<ID3D12PipelineState> mPSOPlus;

				// Dynamic vertex/index buffers (host-visible upload heap), utilisés en
				// RING par frame : chaque SubmitBatches écrit à un offset qui AVANCE
				// (mVBHead/mIBHead), remis à 0 en BeginBackend. Indispensable en DX12 :
				// la command list est EXÉCUTÉE en différé (au Present), donc plusieurs
				// SubmitBatches par frame qui écriraient tous à l'offset 0 se
				// écraseraient mutuellement (tous les draws liraient la dernière copie
				// → fantômes). DX11 (contexte immédiat) n'a pas ce problème.
				ComPtr<ID3D12Resource> mVB;
				ComPtr<ID3D12Resource> mIB;
				void *mVBMap = nullptr;
				void *mIBMap = nullptr;
				D3D12_VERTEX_BUFFER_VIEW mVBView{};
				D3D12_INDEX_BUFFER_VIEW mIBView{};
				UINT64 mVBSize = 0;  // capacité ring VB en octets
				UINT64 mIBSize = 0;  // capacité ring IB en octets
				UINT64 mVBHead = 0;  // tête d'écriture VB (octets) — reset/frame
				UINT64 mIBHead = 0;  // tête d'écriture IB (octets) — reset/frame

				// SRV descriptor heap (one entry per texture + 1 for white)
				ComPtr<ID3D12DescriptorHeap> mSRVHeap;
				uint32 mSRVDescSize = 0;
				uint32 mNextSRVSlot = 0;
				static constexpr uint32 kMaxSRVSlots = 256;

				// Sampler heap
				ComPtr<ID3D12DescriptorHeap> mSamplerHeap;

				// White 1x1 texture
				ComPtr<ID3D12Resource> mWhiteTex;
				uint32 mWhiteSRVSlot = 0;

				// Per-texture SRV slot cache
				struct TexSRVEntry {
						const NkTexture *texture = nullptr;
						uint32 slot = 0;
				};

				NkVector<TexSRVEntry> mTexSRVCache;

				float32 mProjection[16] = {};

				// Helper: get GPU handle for a SRV slot
				D3D12_GPU_DESCRIPTOR_HANDLE GetGPUHandle(uint32 slot) const;
				D3D12_CPU_DESCRIPTOR_HANDLE GetCPUHandle(uint32 slot) const;

				uint32 GetOrCreateSRVSlot(const NkTexture *tex);

				// PSO creation helper
				bool MakePSO(D3D12_BLEND_DESC blendDesc, ComPtr<ID3D12PipelineState> &out, ID3DBlob *vsBlob,
							 ID3DBlob *psBlob);

				// ── NkTextureBackend dispatch (registry globale, cf. .cpp) ────────────
				// Les 5 callbacks doivent etre statiques pour matcher la signature de
				// NkTextureBackend (function pointers sans `this`). Une registry
				// globale (gDX12Registry) tient device/cmdQueue/srvHeap captures
				// depuis Initialize() ainsi que la table des entrees.
				// NOTE : SetFilter/SetWrap sont des NO-OP en DX12 car la root sig
				// utilise un sampler de descriptor heap unique (cree dans CreateSampler
				// avec LINEAR + CLAMP). Pour du per-texture filter/wrap il faudrait
				// ajouter un sampler heap multi-slots ; non implemente pour l'instant.
				static uint32 CreateDX12Texture(uint32 w, uint32 h, const uint8 *rgba);
				static void UpdateDX12Texture(uint32 id, uint32 x, uint32 y, uint32 w, uint32 h, const uint8 *rgba);
				static void DeleteDX12Texture(uint32 id);
				static void SetDX12TextureFilter(uint32 id, NkTextureFilter f);
				static void SetDX12TextureWrap(uint32 id, NkTextureWrap w);

				// ── Dispatch NkRenderTexture (offscreen : resource RT + RTV heap + SRV) ─
				// Bind transitionne PSR->RT + OMSetRenderTargets(offscreen) sur la command
				// list courante ; Unbind transitionne RT->PSR + restaure le back buffer.
				static uint32 CreateDX12RenderTexture(uint32 w, uint32 h);
				static void DestroyDX12RenderTexture(uint32 handle);
				static void BindDX12RenderTexture(uint32 handle);
				static void UnbindDX12RenderTexture();
				static uint32 GetDX12RenderTextureColorId(uint32 handle);
		};

	} // namespace renderer
} // namespace nkentseu
#endif // WINDOWS