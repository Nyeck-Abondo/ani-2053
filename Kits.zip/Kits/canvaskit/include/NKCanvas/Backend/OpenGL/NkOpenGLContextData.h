#pragma once
// =============================================================================
// NkOpenGLContextData.h — Données internes contexte OpenGL (par plateforme)
// =============================================================================
#include "NKCore/NkTypes.h"

#if defined(NKENTSEU_PLATFORM_WINDOWS)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
// Pointeurs de fonctions WGL ARB (utilisés quand NK_NO_GLAD2 est défini)
using PFNWGLCREATECONTEXTATTRIBSARBPROC = HGLRC(WINAPI *)(HDC, HGLRC, const int *);
using PFNWGLCHOOSEPIXELFORMATARBPROC = BOOL(WINAPI *)(HDC, const int *, const FLOAT *, UINT, int *, UINT *);
using PFNWGLSWAPINTERVALEXTPROC = BOOL(WINAPI *)(int);

#elif defined(NKENTSEU_WINDOWING_XLIB)
#include <X11/Xlib.h>
#ifndef NK_NO_GLAD2
#include <glad/glx.h>
#else
#include <GL/glx.h>
#endif

#elif defined(NKENTSEU_WINDOWING_XCB)
#include <xcb/xcb.h>
#include <X11/Xlib.h>
#include <X11/Xlib-xcb.h>
// NE PAS inclure NkX11Clean.h ici : ce fichier est du code X11/GLX pur et il a
// besoin de `None` (Drawable nul de glXMakeCurrent, terminateur des listes
// d'attributs GLX). La neutralisation appartient aux en-tetes moteur qui
// declarent des enumerations en conflit : NKGui.h et NkDeviceInitInfo.h
// l'incluent chez eux, juste avant leurs propres declarations — c'est le bon
// point d'application. L'inclure ici retirait `None` a ses utilisateurs
// legitimes : 5 erreurs dans NkOpenGLContext.cpp, en configuration XCB
// uniquement (la branche XLib ci-dessus ne l'a jamais inclus, et compile).
#ifndef NK_NO_GLAD2
#include <glad/glx.h>
#else
#include <GL/glx.h>
#endif

#elif defined(NKENTSEU_WINDOWING_WAYLAND) || defined(NKENTSEU_PLATFORM_ANDROID) || defined(NKENTSEU_PLATFORM_HARMONYOS)
#ifndef NK_NO_GLAD2
#include <glad/egl.h>
#else
#include <EGL/egl.h>
#include <EGL/eglext.h>
#endif

#elif defined(NKENTSEU_PLATFORM_MACOS)
#ifdef __OBJC__
#import <AppKit/AppKit.h>
#else
// Aligné sur NkCocoaWindow.h (using = objc_object), comme la branche iOS
// ci-dessous : `struct NSView;` entrait en conflit « struct vs type alias »
// dès qu'une unité .cpp non-ObjC incluait les deux en-têtes (révélé par la
// première CI macOS, 2026-08-11).
using NSOpenGLContext = struct objc_object;
using NSOpenGLPixelFormat = struct objc_object;
using NSView = struct objc_object;
#endif

#elif defined(NKENTSEU_PLATFORM_IOS)
#ifdef __OBJC__
#import <UIKit/UIKit.h>
#import <OpenGLES/ES3/gl.h>
#else
// Aligne UIView sur NkUIKitWindow.h (using = objc_object) pour éviter un
// conflit "struct vs type alias" quand les deux en-têtes sont dans la même
// unité de compilation .cpp (non-ObjC).
struct EAGLContext;
using UIView = struct objc_object;
#endif

#elif defined(NKENTSEU_PLATFORM_EMSCRIPTEN)
#include <emscripten/html5.h>
#endif

namespace nkentseu {

	struct NkOpenGLContextData {
			using ProcAddressFn = void *(*)(const char *);

#if defined(NKENTSEU_PLATFORM_WINDOWS)
			HDC hdc = nullptr;
			HGLRC hglrc = nullptr;
			HWND hwnd = nullptr;
			// Stockage des fn ARB pour mode sans GLAD2
			PFNWGLCREATECONTEXTATTRIBSARBPROC _wglCreateCtxARB = nullptr;
			PFNWGLCHOOSEPIXELFORMATARBPROC _wglChoosePFARB = nullptr;
			PFNWGLSWAPINTERVALEXTPROC _wglSwapIntervalEXT = nullptr;

#elif defined(NKENTSEU_WINDOWING_XLIB)
			Display *display = nullptr;
			::Window window = 0;
			GLXContext context = nullptr;
			GLXFBConfig fbConfig = nullptr;

#elif defined(NKENTSEU_WINDOWING_XCB)
			Display *display = nullptr; // bridge Xlib-xcb
			::Window window = 0;
			GLXContext context = nullptr;
			GLXFBConfig fbConfig = nullptr;

#elif defined(NKENTSEU_WINDOWING_WAYLAND) || defined(NKENTSEU_PLATFORM_ANDROID) || defined(NKENTSEU_PLATFORM_HARMONYOS)
			EGLDisplay eglDisplay = EGL_NO_DISPLAY;
			EGLSurface eglSurface = EGL_NO_SURFACE;
			EGLContext eglContext = EGL_NO_CONTEXT;
			EGLConfig eglConfig = nullptr;
			void *eglNativeWindow = nullptr; // wl_egl_window* (Wayland) or ANativeWindow* (Android)

#elif defined(NKENTSEU_PLATFORM_MACOS)
			// void* PARTOUT, y compris en Objective-C++ (2026-09-24). Ces champs
			// etaient types NSOpenGLContext*/... sous __OBJC__ et void* ailleurs :
			// la MEME structure avait deux definitions selon le fichier qui
			// l'incluait (violation de l'ODR), et NkOpenGLContextMacOS.mm -- ecrit
			// pour des void* (CFBridgingRetain / __bridge) -- ne compilait plus.
			// Invisible tant que le .mm n'etait pas compile.
			void *context = nullptr;
			void *pixelFormat = nullptr;
			void *view = nullptr;

#elif defined(NKENTSEU_PLATFORM_IOS)
#ifdef __OBJC__
			EAGLContext *context = nil;
			UIView *view = nil;
			GLuint framebuffer = 0;
			GLuint colorRenderbuffer = 0;
			GLuint depthRenderbuffer = 0;
#else
			void *context = nullptr;
			void *view = nullptr;
			unsigned int framebuffer = 0;
			unsigned int colorRenderbuffer = 0;
			unsigned int depthRenderbuffer = 0;
#endif

#elif defined(NKENTSEU_PLATFORM_EMSCRIPTEN)
			EMSCRIPTEN_WEBGL_CONTEXT_HANDLE context = 0;
			const char *canvasId = "#canvas";

#else
			void *dummy = nullptr;
#endif
			uint32 width = 0;
			uint32 height = 0;
			const char *renderer = "Unknown";
			const char *vendor = "Unknown";
			const char *version = "Unknown";
			ProcAddressFn getProcAddress = nullptr;
	};

} // namespace nkentseu
