#pragma once
// =============================================================================
// NkRenderer2DFactory.h — Creates a 2D renderer from an existing graphics context
//
// Usage:
//   NkIGraphicsContext* gfx = NkContextFactory::Create(window, desc);
//   NkIRenderer2D* r2d = NkRenderer2DFactory::Create(gfx);
//   if (!r2d) { /* unsupported API */ }
//
//   // Each frame:
//   r2d->Clear(NkColor2D::Black);
//   r2d->Begin();
//     r2d->DrawFilledRect({100,100,200,50}, NkColor2D::Red);
//     r2d->DrawSprite(sprite);
//     r2d->DrawText(label);
//   r2d->End();
// =============================================================================
#include "NKCanvas/Renderer/Core/NkIRenderer2D.h"
#include "NKPlatform/NkCGXDetect.h"

namespace nkentseu {

	class NkIGraphicsContext;

	namespace renderer {

		using NkGraphicsApi = graphics::NkGraphicsApi;

		class NkRenderer2DFactory {
			public:
				// Creates and initializes a 2D renderer backed by the given graphics context.
				// The renderer shares the device/command queue — no new GPU device is created.
				// Caller owns the returned pointer : le liberer via Destroy() (jamais `delete`)
				// ou le confier a un NkUniquePtr.
				// Returns nullptr if the API is not supported or initialization fails.
				static NkIRenderer2D *Create(NkIGraphicsContext *ctx);

				// Detruit un renderer cree par Create() : Shutdown() + liberation via
				// l'allocateur NKMemory (symetrique de Create). No-op si nullptr.
				// IMPORTANT : ne JAMAIS faire `delete` sur le pointeur (alloue par NKMemory).
				static void Destroy(NkIRenderer2D *renderer);

				// Convenience: create and wrap in a unique pointer.
				static NkRenderer2DPtr CreateUnique(NkIGraphicsContext *ctx);

				// Check if the given API has a 2D renderer implementation.
				static bool IsApiSupported(NkGraphicsApi api);
		};

	} // namespace renderer
} // namespace nkentseu