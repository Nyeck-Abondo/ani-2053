// =============================================================================
// NkCanvasGuiApp.h — coquille NKCanvas + interface NKGui, EN-TETE SEUL
//
// A QUOI SERT CE FICHIER
//   NkCanvasApp donne la fenetre, la boucle et le cycle de vie. Il ne donne
//   AUCUN moyen de dessiner un rectangle arrondi ou une ligne de texte. Ce
//   fichier ajoute cet etage : contexte NKGui, backend, trois polices, et la
//   liste d'affichage prete a l'emploi a chaque trame.
//
// ⚠️ POURQUOI IL N'A PAS DE .cpp — CE N'EST PAS UN OUBLI
//   Un `.cpp` dans NKCanvas force TOUS ses dependants a compiler et lier ce
//   qu'il inclut. Si cet etage avait un `.cpp`, les quatorze dependants de
//   NKCanvas lieraient NKGui, y compris ceux qui n'en veulent pas.
//   C'est EXACTEMENT le mecanisme qui a fait que NKCanvas liait NKUI — module
//   deprecie — pendant des mois : `NkUICanvasBackend.cpp` existait, et sa seule
//   existence suffisait. `NkGuiCanvasBackend.h`, lui, n'a jamais eu de `.cpp`,
//   et c'est la seule raison pour laquelle NKGui n'a jamais ete impose.
//   NE PAS AJOUTER DE .cpp ICI.
//
// CE QU'IL REGLE ET QU'ON OUBLIE TOUJOURS
//   1. UN texId DISTINCT PAR POLICE. Toute NkGuiFont porte le meme identifiant
//      par defaut : deux polices qui le gardent partagent le meme atlas cote
//      backend et s'ecrasent. Piege paye dans Mou, puis dans Gemcrush. Ici il
//      est impossible de l'oublier.
//   2. LA TAILLE DE POLICE SUIT L'ECRAN, et se RECHARGE a la rotation : un
//      atlas construit pour 14 px reste flou affiche a 28 px.
//   3. LES AIDES DE TEXTE — la vraie dette. `NkGuiDrawList::AddText` ne sait
//      ecrire qu'a la LIGNE DE BASE : ni centrer, ni caler a droite, ni
//      mesurer une hauteur de ligne. C'est ce manque qui force chaque
//      application a reecrire les memes quinze lignes.
//      Mesure : TROIS copies dans le depot avant ce fichier —
//        Labo/Mou/src/Mou/UI/MouDraw.h
//        Labo/Nkoung/...
//        Applications/Gemcrush/src/Gemcrush/Ui/NkGemHud.cpp  (dette datee du
//          2026-08-27, qui nommait deja NKGui comme destination)
//      Trois jeux de plus en auraient fait six. Elles vivent ici desormais.
//
//   📌 LEUR PLACE DEFINITIVE RESTE NKGUI, pas NKCanvas : une application qui
//   utilise NKGui SANS NKCanvas (NKCode, NKCraft) ne les voit toujours pas.
//   Le jour ou quelqu'un ouvre NKGui pour autre chose, elles descendent d'un
//   etage sous le nom NkGuiDrawText.h et cet en-tete les re-exporte. Tant que
//   ce n'est pas fait, ce fichier evite au moins que le compte monte.
//
// OU AJOUTER LA PROCHAINE CHOSE
//   - une aide de dessin utile a TOUTE application  -> ici
//   - une aide propre a un jeu                      -> chez le jeu
//   - une primitive qui manque a NkGuiDrawList      -> dans NKGui, pas ici
// =============================================================================
#pragma once

#include "NKCanvas/App/NkCanvasApp.h"
#include "NKCanvas/App/NkCanvasTexte.h"
#include "NKCanvas/UI/NkGuiCanvasBackend.h"
#include "NKCanvas/App/NkRihenMarque.h"
#include "NKCanvas/App/NkRihenLogo.h"
#include "NKImage/Codecs/SVG/NkSVGCodec.h"
#include "NKGui/Core/NkGuiContext.h"

namespace nkentseu {
	namespace renderer {

		class NkCanvasGuiApp : public NkCanvasApp {
			protected:
				// --- A remplir par le jeu -------------------------------------

				/// Dessin de la trame. `dl` est deja ouverte et sera soumise.
				virtual void OnDraw(nkgui::NkGuiDrawList &dl) {
					(void)dl;
				}

				/// Appele apres le chargement des polices. Rendre false = abandon.
				virtual bool OnGuiInit() {
					return true;
				}

				/// Le pas de temps du jeu. (OnUpdate est deja pris par le relais
				/// interne du delta vers NKGui : le redefinir couperait la trame.)
				virtual void OnTick(float32 deltaTime) {
					(void)deltaTime;
				}

				/// La taille du corps de texte, en pixels, pour cette mise en page.
				/// Relue a chaque OnLayout : la police se recharge si elle change
				/// de plus de 1,5 px.
				///
				/// ⚠️ AJOUTE LE 2026-09-29 POUR LES EDITEURS. Le defaut suit
				/// l'ecran (petit cote x 0,036), ce qui est juste pour un JEU
				/// qu'on lit a bout de bras sur un telephone -- et donne 27 px
				/// sur un bureau de 760 px de haut : bien trop gros pour un
				/// editeur dense (UnkenyEditor veut ~13 px). Le defaut ne change
				/// pas : aucun jeu existant ne bouge tant qu'il ne le redefinit pas.
				virtual float32 TaillePoliceCorps(const NkLayoutInfo &lay) const noexcept {
					return SuggestedBodyPx(lay);
				}

				// --- Services -------------------------------------------------
				nkgui::NkGuiContext &Gui() noexcept {
					return mGuiContext;
				}
				nkgui::NkGuiFont *FontBody() noexcept {
					return &mFontBody;
				}
				nkgui::NkGuiFont *FontTitle() noexcept {
					return &mFontTitle;
				}
				nkgui::NkGuiFont *FontSmall() noexcept {
					return &mFontSmall;
				}

				/// L'identifiant de texture du symbole Rihen, ou 0 s'il n'a pas pu
				/// etre rasterise.
				///
				/// ⚠️ ZERO EST UNE REPONSE, PAS UNE PANNE. L'appelant doit pouvoir
				/// dessiner sans logo — un splash qui refuserait de s'afficher parce
				/// qu'un decodage SVG a echoue transformerait un defaut cosmetique en
				/// application morte.
				uint32 LogoRihenTexId() const noexcept {
					return mLogoPret ? NkRihenMarqueTexId() : 0u;
				}

				/// Le LOGO COMPLET — le mot RIHEN dessine, pas seulement le
				/// symbole. Zero s'il n'a pas pu etre rasterise.
				///
				/// Rodolf, le 13 septembre 2026 : « sur ces jeux le logo de
				/// Rihen est deteriore contrairement a Pong ». Pong affichait le
				/// logo reel charge depuis le disque ; l'ouverture commune
				/// n'avait que le symbole a 256 px et ecrivait le mot avec une
				/// police. Zero reste une reponse : l'appelant retombe alors sur
				/// le symbole, comme avant.
				uint32 LogoCompletRihenTexId() const noexcept {
					return mLogoCompletPret ? NkRihenLogoTexId() : 0u;
				}

				/// Televerse une image RGBA (4 octets par pixel, lignes jointives)
				/// sous `texId`, pour AddImage / AddImagePolygon.
				///
				/// ⚠️ AJOUTE LE 2026-09-29. Le backend est un membre PRIVE : une
				/// application qui voulait dessiner une image devait en creer un
				/// second (Mou le fait) — deux backends, deux jeux de textures.
				/// Rend false avant OnGuiInit (aucun rendu) ou si le rendu refuse.
				bool TeleverserImage(uint32 texId, const uint8 *rgba, int32 w, int32 h) noexcept {
					return mGuiReady && mGuiBackend.UploadImageRGBA(texId, rgba, w, h);
				}

				/// Televerse l'atlas d'une police SUPPLEMENTAIRE (chargee par
				/// l'application) sous son `texId`.
				///
				/// ⚠️ AJOUTE LE 2026-10-01, POUR LE TERMINAL D'UNKENYEDITOR : il lui
				/// faut une police a chasse fixe, et les trois polices de cette
				/// coquille sont proportionnelles. Meme raison que TeleverserImage :
				/// le backend est prive, et un second backend ferait un second jeu de
				/// textures. Le `texId` doit etre DISTINCT des trois polices d'ici
				/// (voir l'en-tete du fichier, piege n.1). Rend false avant
				/// OnGuiInit ou si la police n'a pas d'atlas.
				bool TeleverserPolice(const nkgui::NkGuiFont &f) noexcept {
					return mGuiReady && f.pixels != nullptr && f.atlasW > 0 && f.atlasH > 0 &&
						   mGuiBackend.UploadFontGray8(f.TexId(), f.pixels, f.atlasW, f.atlasH);
				}

				/// Le meme relais, en fonction LIBRE : `app` est l'application.
				/// C'est la forme qu'attend unkeny::NkTextures2D::Brancher, qui ne
				/// connait pas NKCanvas :
				///     mTextures.Brancher(&NkCanvasGuiApp::RelaisTeleversement,
				///                        static_cast<NkCanvasGuiApp *>(this));
				/// ⚠️ Le static_cast n'est pas decoratif : passer `this` d'une classe
				/// derivee a heritage multiple donnerait une adresse decalee, et ce
				/// relais la relirait comme un NkCanvasGuiApp.
				static bool RelaisTeleversement(void *app, uint32 texId, const uint8 *rgba, int32 w, int32 h) noexcept {
					return app != nullptr && static_cast<NkCanvasGuiApp *>(app)->TeleverserImage(texId, rgba, w, h);
				}

				// =============================================================
				// AIDES DE TEXTE — DES RELAIS, plus des implementations.
				//
				// ⚠️ CORRECTION DU 2026-09-01. Elles etaient ecrites ICI, en
				// methodes protegees. Le resultat s'est mesure tout seul : les
				// trois jeux de plateau dessinent depuis des FONCTIONS LIBRES
				// (leur fichier d'ecran ne connait pas la classe d'application),
				// donc aucun des trois n'a pu s'en servir — et les trois les ont
				// RE-ECRITES. Une aide rangee dans une classe n'est disponible
				// que pour ce qui herite de cette classe : c'est une PORTEE, pas
				// un detail de style.
				//
				// Le corps vit desormais dans NkCanvasTexte.h, en fonctions
				// libres. Ce qui reste ici n'existe que pour les appels deja
				// ecrits — il ne doit plus jamais grossir.
				// =============================================================
				static float32 MeasureW(nkgui::NkGuiFont *f, const char *s) noexcept {
					return NkTexteLargeur(f, s);
				}
				static float32 LineH(nkgui::NkGuiFont *f, float32 fallback) noexcept {
					return NkTexteHauteurLigne(f, fallback);
				}
				static void Text(nkgui::NkGuiDrawList &dl, nkgui::NkGuiFont *f, float32 x, float32 topY, const char *s,
								 const nkgui::NkColor &c, float32 maxWidth = -1.f) noexcept {
					NkTexte(dl, f, x, topY, s, c, maxWidth);
				}
				static void TextCentered(nkgui::NkGuiDrawList &dl, nkgui::NkGuiFont *f, float32 cx, float32 topY,
										 const char *s, const nkgui::NkColor &c) noexcept {
					NkTexteCentre(dl, f, cx, topY, s, c);
				}
				static void TextInBox(nkgui::NkGuiDrawList &dl, nkgui::NkGuiFont *f, const nkgui::NkRect &box,
									  const char *s, const nkgui::NkColor &c) noexcept {
					NkTexteDansBoite(dl, f, box, s, c);
				}
				static void TextRight(nkgui::NkGuiDrawList &dl, nkgui::NkGuiFont *f, float32 right, float32 topY,
									  const char *s, const nkgui::NkColor &c) noexcept {
					NkTexteADroite(dl, f, right, topY, s, c);
				}

				// --- Cycle de vie de la coquille ------------------------------
				bool OnInit() override {
					const NkLayoutInfo &lay = Layout();

					if (!mGuiContext.Init(static_cast<int32>(lay.width), static_cast<int32>(lay.height))) {
						logger.Error("[nkcanvasgui] initialisation de NkGuiContext ECHOUEE");
						return false;
					}
					nkgui::SetCurrentContext(&mGuiContext);

					if (!mGuiBackend.Init(Target().GetRenderer())) {
						logger.Error("[nkcanvasgui] initialisation de NkGuiCanvasBackend ECHOUEE");
						return false;
					}

					LoadFonts(TaillePoliceCorps(lay));
					mGuiContext.font = &mFontBody;
					mGuiReady = true;
					return OnGuiInit();
				}

				void OnUpdate(float32 deltaTime) final {
					// La liste d'affichage reclame le pas de temps a BeginFrame,
					// plus tard dans la trame. On le retient plutot que de le
					// recalculer : deux horloges qui doivent s'accorder finissent
					// toujours par diverger.
					mLastDelta = deltaTime;
					OnTick(deltaTime);
				}

				void OnRender(NkRenderWindow &target) final {
					const math::NkVec2u size = target.GetSize();
					mGuiContext.BeginFrame(mLastDelta);
					OnDraw(mGuiContext.dl);
					mGuiContext.EndFrame();
					mGuiBackend.Submit(mGuiContext.dl, size.x, size.y);
					mGuiBackend.Submit(mGuiContext.dlOverlay, size.x, size.y);
				}

				void OnLayout(const NkLayoutInfo &layout) override {
					if (!mGuiReady) {
						return; // OnInit n'a pas encore tourne : rien a recharger
					}
					const float32 wanted = TaillePoliceCorps(layout);
					const float32 ecart = wanted > mLoadedPx ? wanted - mLoadedPx : mLoadedPx - wanted;
					if (ecart < 1.5f) {
						return; // sous ce seuil le rechargement ne se voit pas
					}
					LoadFonts(wanted);
				}

			private:
				static float32 SuggestedBodyPx(const NkLayoutInfo &lay) noexcept {
					// La police suit la plus PETITE dimension : c'est elle qui
					// borne la lecture, en portrait comme en paysage.
					const float32 minSide = static_cast<float32>(lay.width < lay.height ? lay.width : lay.height);
					const float32 px = minSide * 0.036f;
					return px < 11.f ? 11.f : (px > 34.f ? 34.f : px);
				}

				/// Rasterise le symbole embarque et le televerse. Une seule fois.
				void ChargerLogoRihen() {
					if (mLogoPret) {
						return;
					}
					const char *svg = NkRihenMarqueSVG();
					usize n = 0;
					while (svg[n] != '\0') {
						++n;
					}
					const int32 t = NkRihenMarqueTaille();
					NkImage img = NkSVGCodec::Decode(reinterpret_cast<const uint8 *>(svg), n, t, t);
					if (!img.IsValid() || img.Pixels() == nullptr) {
						// On le DIT plutot que d'echouer en silence : sans cette ligne,
						// un logo absent se chercherait dans le splash, c'est-a-dire
						// loin de sa cause.
						logger.Warn("[nkcanvasgui] symbole Rihen non rasterise — l'ouverture s'affichera sans lui");
						return;
					}
					mLogoPret = mGuiBackend.UploadImageRGBA(NkRihenMarqueTexId(), img.Pixels(), img.Width(),
															   img.Height());
					if (!mLogoPret) {
						logger.Warn("[nkcanvasgui] televersement du symbole Rihen refuse");
					}
				}

				/// Rasterise le LOGO COMPLET embarque et le televerse. Une fois.
				///
				/// Il est rasterise a sa definition d'affichage (1024 de large),
				/// et non a 256 comme le symbole : c'est precisement l'ecart qui
				/// faisait paraitre l'ouverture degradee a cote de Pong.
				///
				/// Un echec N'EST PAS une panne : l'ouverture retombe sur le
				/// symbole. On le DIT, comme pour le symbole, pour que la cause
				/// ne se cherche pas dans le splash.
				void ChargerLogoCompletRihen() {
					if (mLogoCompletPret) {
						return;
					}
					const char *svg = NkRihenLogoSVG();
					usize n = 0;
					while (svg[n] != '\0') {
						++n;
					}
					NkImage img = NkSVGCodec::Decode(reinterpret_cast<const uint8 *>(svg), n,
													 NkRihenLogoLargeur(), NkRihenLogoHauteur());
					if (!img.IsValid() || img.Pixels() == nullptr) {
						logger.Warn("[nkcanvasgui] logo complet non rasterise — l'ouverture gardera le symbole");
						return;
					}
					mLogoCompletPret = mGuiBackend.UploadImageRGBA(NkRihenLogoTexId(), img.Pixels(), img.Width(),
																   img.Height());
					if (!mLogoCompletPret) {
						logger.Warn("[nkcanvasgui] televersement du logo complet refuse");
					}
				}

				void LoadFonts(float32 bodyPx) {
					// ⚠️ texId DISTINCT par police — voir l'en-tete de fichier.
					mFontBody.texId = 0x4E4B4654u;
					mFontTitle.texId = mFontBody.texId + 1u;
					mFontSmall.texId = mFontBody.texId + 2u;

					const bool ok = mFontBody.LoadEmbedded(NkEmbeddedFontId::DroidSans, bodyPx) ||
									mFontBody.LoadEmbedded(NkEmbeddedFontId::ProggyClean, bodyPx);
					mFontTitle.LoadEmbedded(NkEmbeddedFontId::DroidSans, bodyPx * 1.85f);
					mFontSmall.LoadEmbedded(NkEmbeddedFontId::DroidSans, bodyPx * 0.78f);

					nkgui::NkGuiFont *fonts[3] = {&mFontBody, &mFontTitle, &mFontSmall};
					for (int32 i = 0; i < 3; ++i) {
						if (fonts[i]->pixels != nullptr && fonts[i]->atlasW > 0 && fonts[i]->atlasH > 0) {
							mGuiBackend.UploadFontGray8(fonts[i]->TexId(), fonts[i]->pixels, fonts[i]->atlasW,
														fonts[i]->atlasH);
						}
					}
					if (!ok) {
						logger.Warn("[nkcanvasgui] aucune police chargee — les textes seront absents");
					}
					mLoadedPx = bodyPx;

					// Le logo suit les polices : meme backend, meme instant de
					// disponibilite. Il ne depend PAS de la taille demandee, donc il
					// ne se recharge pas a chaque rotation d'ecran.
					ChargerLogoRihen();
					ChargerLogoCompletRihen();
				}

				nkgui::NkGuiContext mGuiContext;
				NkGuiCanvasBackend mGuiBackend;
				nkgui::NkGuiFont mFontBody, mFontTitle, mFontSmall;
				float32 mLoadedPx = 0.f;
				float32 mLastDelta = 1.f / 60.f;
				bool mGuiReady = false;
				bool mLogoPret = false;
				bool mLogoCompletPret = false;
		};

	} // namespace renderer
} // namespace nkentseu
